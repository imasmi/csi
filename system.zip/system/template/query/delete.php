<?php
//$PDO->query("DELETE FROM " . $File->table . " WHERE id='" . $_GET["id"] . "'");
//\system\Query::cleanup($value,  $selector="id", $table="module", $delimeter="=")
//Use #\system\Query::cleanup function to delete data from default Imasmi web tables (page | text | file | setting)
?>
<script>history.go(-1)</script>