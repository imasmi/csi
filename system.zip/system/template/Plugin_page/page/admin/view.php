<?php
$Object = $Plugin->object(false, $_GET["id"]);
$Object->item($_GET["id"]);
?>