<?php
$Object = $Plugin->object(false, $_GET["id"]);
$Object->_();
?>