<?php
echo $Text->_("Something went wrong with your activation. Please try again or contact us for more information.");
?>