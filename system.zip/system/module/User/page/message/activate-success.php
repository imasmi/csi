<div class="text-center">
    <?php echo $Text->_("Your user is activated successfuly. You can log in now.");?>
</div>