<?php
echo $Text->_("Your new password is sended to you email.");
?>