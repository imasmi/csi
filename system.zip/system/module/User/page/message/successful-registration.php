<?php
echo $Text->_("Your registration was successful. Please visit your email to activate your profile.");
?>