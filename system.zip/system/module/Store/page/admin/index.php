<?php
$store = file_get_contents("https://web.imasmi.com/Webstore/query/store");
echo $store;
?>