<h1>System</h1>
    <span>Location: /system</span>
    <span>The system folder is the system itself. The whole structure is created in the files in it, with all the main php classes, javascript libraries, modules and others.</span>
    <p class="manual-hint">On updates the whole system folder is overwritten, so don't change anything in the code, because you will lose your changes when update to the new versions.</p>
    <span>The system folder follows the <a class="manual-link" onclick="view('structure');">structure</a> model pattern.</span>