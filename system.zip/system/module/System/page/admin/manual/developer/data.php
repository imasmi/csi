<h1>Data</h1>
    <span>Location: /data</span>
    <span>Data folder stores system data such as backups, logs, cache files and etc.</span>
    <p class="manual-hint">Data folder is not present at installation of the system and is created automatically by the system when needed.</p>