<h1>System security</h1>
    <span>The work of improving security never stops and ImaSmi Web security is constantly improving.</span>
    <span>We always try to show only what is necessary to the world and to prevent unauthorized access to the system data.</span>
    <p class="manual-hint">Working on security should be everyones main concern when developing a new theme or plugin.</p>
    <span>To be sure about security, regular tests are recommended.</span>
    <p class="manual-hint">It is important to test the whole system, because somethimes an istalled theme or plugin may have security leaks also.</p>