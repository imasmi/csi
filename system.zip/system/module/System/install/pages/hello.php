<h1 class="text-center">ImaSmi Web</h1>
<div>ImaSmi Web is enviorment to create web pages and web applications.</div>
<div>Using it is easy as installing it. Just agree our terms and press install.</div>
<form action="?page=install" method="post" class="marginY-20 text-center">
    <input type="checkbox" name="terms" required/> Terms and conditions. View <a href="<?php echo \system\Core::url();?>license.txt" target="_blank" class="color-2">here</a><br/>
    <button class="button marginY-20">INSTALL</button>
</form>