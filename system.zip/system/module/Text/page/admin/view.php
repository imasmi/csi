<div class="admin">
    <div class="padding-20"><?php echo $Text->item($_GET["id"]);?></div>
    <div class="text-center"><button type="button" class="button" onclick="history.go(-1)"><?php echo $Text->item("Back");?></button></div>
</div>