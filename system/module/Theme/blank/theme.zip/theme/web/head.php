<?php echo $Page->head();?>
<link rel="stylesheet" href="<?php echo \system\Core::url();?>web/css/style.css">