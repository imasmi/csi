<div class="frame clear">
    <div class="column-2"><?php echo $File->_("Logo", ["page_id" => 0]);?></div>
    <div class="column-8 text-center">
        <?php
            $Menu_header = new \module\Page\Menu("header");
            echo $Menu_header->_();
        ?>
    </div>
    <div class="column-2 text-right">
        <div><?php echo $User->logger();?></div>
        <div><?php echo $Language->changer();?></div>
    </div>
</div>