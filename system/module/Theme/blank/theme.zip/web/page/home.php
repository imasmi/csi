<section id="intro" class="frame">
    <h2>Hello and welcome to your blank theme.</h2>
    <p>It is created for you as a starting point to create your new theme.</p>
    <p>ImaSmi Web follows strictly defined strucure pattern for files and folders. This pattern is pretty much the same for themes and plugins and it will make it so much easier for you in the future to orientate and find things, no matter if the code is writen by you or by someone else.</p>
    <p>This blank theme contains most of the essentials for a standart web application. Here are some things included: 
        <ul>
            <li>seo, mobile and social media friendly meta tags;</li>
            <li>blank css file attached in the head;</li>
            <li>blank javascript file attached before the closing body tag;</li>
            <li>logo file changer, header menu, user logger and language changer (you must add more languages to appear) in the footer section;</li>
            <li>footer menu and system credit in the footer section;</li>
            <li>home page with this instructions, one file changer and one text filler.</li>
        </ul>
    </p>
    
    <p>You will learn a lot for ImaSmi Web only if you explore this blank theme structure in the <b>/web</b> folder in your document root</p>
    <p>Of course this is only the tip of the iceberg and you will be able to do so much more after reading our <a href="<?php echo \system\Core::url();?>System/admin/manual/developer/index" class="button">developers manual</a></p>
    <p>Finally, just to feel a little of the superpowers of ImaSmi Web, click two times on the <b>black camera</b> below to add your first media or click one time at the <b>Empty text</b> placeholder to start writing you first text. After finishing it, just click somewhere else and it will save it.</p>
</section>

<section id="home" class="frame clear paddingY-60">
    <div class="column-6 padding-20"><?php echo $File->_("Home image");?></div>
    <div class="column-6 padding-20"><?php echo $Text->_("Home text");?></div>
</section>