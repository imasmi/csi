<div class="clear frame text-center">
    <div class="column-6">
        <?php
            $Menu_footer = new \module\Page\Menu("footer");
            echo $Menu_footer->_();
        ?>
    </div>
    
    <div class="column-6">
        <?php echo \system\Core::credit();?>
    </div>
</div>