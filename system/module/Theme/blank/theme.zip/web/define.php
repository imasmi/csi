<?php
include_once(\system\Core::doc_root() . "/system/module/Page/php/Menu.php");
?>